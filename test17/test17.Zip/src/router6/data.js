export default [
    {
        id: "1",
        name: "나이키1",
        description: "[입점사][사은품 증정] 나이키 알파플라이 2 남성 로드 레이싱화",
        photo:'https://static.nike.com/a/images/t_default/bb8f3b69-8a65-4d52-8a60-fec0bd0c7227/%EC%95%8C%ED%8C%8C%ED%94%8C%EB%9D%BC%EC%9D%B4-2-%EB%82%A8%EC%84%B1-%EB%A1%9C%EB%93%9C-%EB%A0%88%EC%9D%B4%EC%8B%B1%ED%99%94-tL7CEVL8.png',
        price: 189000
    },
    {
        id: "2",
        name: "나이키2",
        description: "[입점사][사은품 증정] 루카 2 '레이크 블레드' PF 농구화",
        photo:'https://static.nike.com/a/images/t_default/u_126ab356-44d8-4a06-89b4-fcdcc8df0245,c_scale,fl_relative,w_1.0,h_1.0,fl_layer_apply/c166fbfb-dc86-4b82-9be9-01426f437454/%EB%A3%A8%EC%B9%B4-2-%EB%A0%88%EC%9D%B4%ED%81%AC-%EB%B8%94%EB%A0%88%EB%93%9C-pf-%EB%86%8D%EA%B5%AC%ED%99%94-l0C0qRoQ.png',
        price: 169000 
    },
    {
        id: "3",
        name: "나이키3",
        description: "[2023 S/S 신상품]  조던 맥스 아우라 5 남성 신발",
        photo:'https://static.nike.com/a/images/t_default/u_126ab356-44d8-4a06-89b4-fcdcc8df0245,c_scale,fl_relative,w_1.0,h_1.0,fl_layer_apply/e167643b-ee50-49f6-9705-5f0eee2178bb/%EC%A1%B0%EB%8D%98-%EB%A7%A5%EC%8A%A4-%EC%95%84%EC%9A%B0%EB%9D%BC-5-%EB%82%A8%EC%84%B1-%EC%8B%A0%EB%B0%9C-HOmNFzIb.png',
        price: 159000
    },
    {
        id: "4",
        name: "나이키4",
        description: "[온라인 단독상품]  나이키 프리 메트콘 5 여성 운동화",
        photo:'https://static.nike.com/a/images/t_default/59fe2604-478d-4053-a742-8e15a13e5b34/%ED%94%84%EB%A6%AC-%EB%A9%94%ED%8A%B8%EC%BD%98-5-%EC%97%AC%EC%84%B1-%EC%9A%B4%EB%8F%99%ED%99%94-gxH3kLAG.png',
        price: 139000
    }
]