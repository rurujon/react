import React from 'react';

const NotProduct = () => {
    return (
        <div>
            <h1>제품을 찾을 수 없습니다.</h1>
        </div>
    );
};

export default NotProduct;