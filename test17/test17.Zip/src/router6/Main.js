import React from 'react';

const Main = () => {
    return (
        <div>
            <h1>운동화 쇼핑몰 입니다.</h1>
            <h2>방문해 주셔서 감사합니다.</h2>
        </div>
    );
};

export default Main;