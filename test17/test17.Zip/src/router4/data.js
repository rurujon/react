export default  {
  user1:{
    name:'정인선',
    job:'웹디자이너'
  },
  user2:{
    name:'배수지',
    job:'웹퍼블리셔'
  },
  user3:{
    name:'박신혜',
    job:'프론트엔드 개발자'
  },
  user4:{
    name:'유인나',
    job:'백엔드 개발자'
  }
}