import React from 'react';

const About = () => {
    return (
        <div>
            <h1>About 페이지</h1>
        </div>
    );
};

export default About;