import React from 'react';

const Sub = () => {
    return (
        <div>
            <h1>Sub 페이지</h1>
        </div>
    );
};

export default Sub;