export default [
    {title:'html',info:'html에 대한 설명입니다'},
    {title:'css',info:'css에 대한 설명입니다'},
    {title:'javascript',info:'javascript에 대한 설명입니다'},
    {title:'react',info:'react에 대한 설명입니다'}
  ]