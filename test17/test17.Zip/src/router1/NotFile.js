import React from 'react';

const NotFile = () => {
    return (
        <div>
            <h1>페이지가 없다.</h1>
        </div>
    );
};

export default NotFile;