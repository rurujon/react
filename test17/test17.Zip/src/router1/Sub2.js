import React from 'react';

const Sub2 = () => {
    return (
        <div>
            <h1>Sub2 Page</h1>
        </div>
    );
};

export default Sub2;