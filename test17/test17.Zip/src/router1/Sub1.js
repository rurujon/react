import React from 'react';

const Sub1 = () => {
    return (
        <div>
            <h1>Sub1 Page</h1>
        </div>
    );
};

export default Sub1;