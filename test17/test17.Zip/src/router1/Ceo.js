import React from 'react';

const Ceo = () => {
    return (
        <div>
            <h1>Ceo입니다</h1>
        </div>
    );
};

export default Ceo;