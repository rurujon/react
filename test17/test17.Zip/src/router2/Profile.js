import React from 'react';

const Profile = () => {
    return (
        <div>
            <h1>Profile Page</h1>
        </div>
    );
};

export default Profile;