import React from 'react';

const NotMember = () => {
    return (
        <div>
            <h2>멤버가 아닙니다.</h2>
        </div>
    );
};

export default NotMember;