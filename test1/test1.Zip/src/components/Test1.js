import React from 'react'

const Test1 = () => {

    //컴포넌트 함수 영역
    return(

        <h2>JSX영역 : 화면에 보이는 영역</h2>

    )
    
}

export default Test1