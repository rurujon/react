import Customer from './customer/Customer';

function App() {
  return (
    <div>
      <Customer/>
    </div>
  );
}

export default App;
