import Test1 from './components/Test1';
import Test2 from './components/Test2';
import Melon from './melon/Melon';

function App() {
  return (
    <div>
      {/* <Test1/> */}
      {/* <Test2/> */}
      <Melon/>
    </div>
  );
}

export default App;
