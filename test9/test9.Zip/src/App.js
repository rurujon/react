import Friend from "./friend/Friend";
import Movies from "./movies/Movies";


function App() {
  return (
    <div>
      {/* <Friend/> */}
      <Movies/>
    </div>
  );
}

export default App;
