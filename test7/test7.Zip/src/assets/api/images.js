const images = [
    {id:1,image:'./p_images/angelina1.jpg',title:'안젤리나1',desc:'안젤리나1 이미지 세부 사항'},
    {id:2,image:'./p_images/angelina2.jpg',title:'안젤리나2',desc:'안젤리나2 이미지 세부 사항'},
    {id:3,image:'./p_images/angelina3.jpg',title:'안젤리나3',desc:'안젤리나3 이미지 세부 사항'},
    {id:4,image:'./p_images/angelina4.jpg',title:'안젤리나4',desc:'안젤리나4 이미지 세부 사항'},
    {id:5,image:'./p_images/angelina5.jpg',title:'안젤리나5',desc:'안젤리나5 이미지 세부 사항'}
]

export default images