import Test1 from './conponents/Test1';
import Test2 from './conponents/Test2';
import Gallery from './gallery/Gallery';
import Movies from './movies/Movies';
import Starbucks from './starbucks/Starbucks';

function App() {
  return (
    <div>
      {/* <Test1/> */}
      {/* <Test2/> */}
      {/* <Movies/> */}
      {/* <Gallery/> */}
      <Starbucks/>
    </div>
  );
}

export default App;
