import Todos from "./todos/Todos";


function App() {
  return (
    <div>
      <Todos/>
    </div>
  );
}

export default App;
