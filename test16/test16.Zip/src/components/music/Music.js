import React from 'react';

const Music = () => {
    return (
        <div>
            <h2>Music Component 입니다.</h2>
        </div>
    );
};

export default Music;