export default [
    {
        id:1,
        text:'업체미팅',
        day:'2024.07.10 / pm 03:00',
        done: true   //true이면 일정이 선택된것으로 보임
    },
    {
        id:2,
        text:'전체회의',
        day:'2024.07.12 / am 10:00',
        done: false 
    },
    {
        id:3,
        text:'부서회의',
        day:'2024.07.13 / pm 02:00',
        done: false 
    },
    {
        id:4,
        text:'친구와약속',
        day:'2024.07.15 / pm 07:00',
        done: false 
    },
]