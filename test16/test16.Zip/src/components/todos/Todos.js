import React from 'react';

const Todos = () => {
    return (
        <div>
            <h2>Todos Component 입니다.</h2>
        </div>
    );
};

export default Todos;