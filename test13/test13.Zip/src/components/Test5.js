import React from 'react';
import './Test5.scss'

const Test5 = () => {
    return (
        <div className='wrap'>
            <div className='box red'>red</div>
            <div className='box green'>green</div>
            <div className='box blue'>blue</div>
            <div className='box pink'>pink</div>
            <div className='box tomato'>tomato</div>
            <div className='box skyblue'>skyblue</div>
            
        </div>
    );
};

export default Test5;