import React from 'react';

const SurveyStep4 = ({name}) => {
    return (
        <>
            <h2>
                <span>{name}님 </span>
                설문조사 감사합니다
            </h2>
            
        </>
    );
};

export default SurveyStep4;