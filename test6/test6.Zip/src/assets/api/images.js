export default [
    {id:1, image:'./p_images/suzi0.jpg', title:'수지1'},
    {id:2, image:'./p_images/suzi1.jpg', title:'수지2'},
    {id:3, image:'./p_images/suzi2.jpg', title:'수지3'},
    {id:4, image:'./p_images/suzi3.jpg', title:'수지4'},
    {id:5, image:'./p_images/suzi4.jpg', title:'수지5'},
    {id:6, image:'./p_images/suzi5.jpg', title:'수지6'}
]