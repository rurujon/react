export default [      
    {no:1, poster:'https://img.megabox.co.kr/SharedImg/2023/07/27/VLZ7NCAlhfkHLvOaKvgTeXvRGPdaTemN_420.jpg', title:'잠', date:'2023.09.06',actor:'정유미, 이선균',director:'유재선'},
    {no:2, poster:'https://img.megabox.co.kr/SharedImg/2023/08/31/LxMJPlnjMFzURqYBUyZsDRfxmkCNJBAR_420.jpg', title:'타겟', date:'2023.08.30',actor:'신혜선, 김성균',director:'박희곤'},
    {no:3, poster:'https://img.megabox.co.kr/SharedImg/2023/07/26/HlwoWJD0GGvQWX5FnkUDEPmlaCAlmN0Z_420.jpg', title:'오펜하이머', date:'2023.08.15',actor:'킬리언 머피',director:'크리스토퍼 놀란'},
    {no:4, poster:'https://img.megabox.co.kr/SharedImg/2023/08/09/MQktVBcUKNDdf3iXacSgWeAyp5g56S9N_420.jpg', title:'콘크리트 유토피아', date:' 2023.08.09',actor:'이병헌, 박보영',director:'엄태화'},
    {no:5, poster:'https://img.megabox.co.kr/SharedImg/2023/08/17/0Fw087huXAHdxHKlspDwT85UtAlsczIL_420.jpg', title:'달짝지근해: 7510', date:'2023.08.15',actor:'유해진, 김희선',director:'이한'},
    {no:6, poster:'https://img.megabox.co.kr/SharedImg/2023/07/17/2VGGGrBFIl8dOoqYw2jBF8JLSZKN3gu5_420.jpg', title:'밀수', date:'2023.07.26',actor:'김혜수, 조인성',director:'류승완'},
    {no:7, poster:'https://img.megabox.co.kr/SharedImg/2023/09/04/2TmCCjK9lGsJG0Mc5AtY3CBK0twKJ66f_420.jpg', title:'스파이 코드명 포춘', date:'2023.08.30',actor:'제이슨 스타뎀',director:'가이 리치'},
    {no:8, poster:'https://img.megabox.co.kr/SharedImg/2023/05/26/UsO9OFOUA1z4jGKYVNK6mCX9AVT1zDEe_420.jpg', title:'엘리멘탈', date:'2023.06.14',actor:' 레아 루이스',director:'피터 손'},
    {no:9, poster:'https://img.megabox.co.kr/SharedImg/2023/06/11/51LUhknQCeQgeUqXUXMPgdBrBT3bSPVl_420.jpg', title:'스파이더맨', date:'2023.06.21',actor:'샤메익 무어',director:'저스틴 톰슨'}    
]