import React from 'react';

const Test3Display = ({name,hobby}) => {
    return (
        <div>
            {name}가 좋아하는 취미는 {hobby}입니다.
            
        </div>
    );
};

export default Test3Display;