import Test1 from './components/Test1';
import Test2 from './components/Test2';
import Test3 from './components/Test3';
import Test4 from './components/Test4';
import News from './sample/newsViewer/News';
import Gallery from './sample/pixabay/Gallery';

function App() {
  return (
    <div>
      {/* <Test1/> */}
      {/* <Test2/> */}
      {/* <Test3/> */}
      {/* <Test4/> */}
      {/* <Gallery/> */}
      <News/>
    </div>
  );
}

export default App;
